# payproof CLI

The `payproof` command runs PayProof against an existing application's webhook
URL. It is black-box by default: the target does not need PayProof routes,
controllers, services, or checkpoint instrumentation.

```bash
pnpm add -D payproof
pnpm exec payproof init
PAYPROOF_TARGET_URL=http://127.0.0.1:3000 pnpm exec payproof test
```

`payproof init` creates `payproof.config.mjs` and
`tests/payproof.test.mjs`. The generated test sends a synthetic,
documented-shaped Bachs event and reports delivery success. It intentionally
warns that black-box delivery is not deterministic race-condition coverage and
does not prove committed financial correctness.

Add a test-side `verify(reference)` callback to query the application's own
committed database state when financial correctness should be asserted. This
does not require changing the production webhook code. Set
`requireFinancialVerification: true` to fail when the callback or an HTTP state
inspection endpoint is absent.

For deeper race testing, configure `checkpoint` and instrument the target only
in its explicit test environment with `@payproof/sdk`:

```ts
await checkpoint("after-idempotency-check", { key: payment.reference });
```

That is an optional white-box mode. The CLI never implies that ordinary
black-box HTTP delivery is deterministic concurrency coverage.
