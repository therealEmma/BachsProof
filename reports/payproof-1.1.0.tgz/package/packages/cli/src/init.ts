import { access, mkdir, writeFile } from "node:fs/promises";
import { constants } from "node:fs";
import { join, resolve } from "node:path";

const configTemplate = `import { bachsAdapter } from "payproof";
import { tests } from "./tests/payproof.test.mjs";

const signingSecret = process.env.BACHS_WEBHOOK_SECRET;

export default {
  provider: bachsAdapter({ mode: "mock" }),
  target: {
    baseUrl: process.env.PAYPROOF_TARGET_URL ?? "http://127.0.0.1:3000",
    webhookPath: process.env.PAYPROOF_WEBHOOK_PATH ?? "/webhooks/bachs",
    // The CLI is black-box by default; isolation belongs to your test data.
    reset: false
  },
  tests,
  // Add a test-side verify(reference) callback when you want committed-state
  // financial assertions. It does not modify your production webhook code.
  ...(signingSecret ? { signing: { type: "bachs", secret: signingSecret } } : {})
};
`;

const testTemplate = `export const tests = [
  {
    name: "black-box duplicate delivery",
    scenario: "sequential-duplicate-webhook",
    reference: process.env.PAYPROOF_REFERENCE ?? \`PAYPROOF-INIT-\${Date.now()}\`,
    amountMinor: 5_000_000,
    currency: "NGN"
  }
];

// Optional committed-state verifier. Keep this in the test project, not in
// production. Add \`verify\` to payproof.config.mjs when it is implemented.
//
// export async function verify(reference) {
//   const credits = await testDatabase.walletCredit.findMany({ where: { reference } });
//   return {
//     reference,
//     creditCount: credits.length,
//     creditedAmountMinor: credits.reduce((sum, credit) => sum + Number(credit.amountMinor), 0),
//     currency: credits[0]?.currency ?? "NGN"
//   };
// }
`;

async function exists(path: string): Promise<boolean> {
  try {
    await access(path, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

export async function initProject(directory = process.cwd(), force = false): Promise<string[]> {
  const root = resolve(directory);
  const configPath = join(root, "payproof.config.mjs");
  const testDirectory = join(root, "tests");
  const testPath = join(testDirectory, "payproof.test.mjs");
  const paths = [configPath, testPath];
  if (!force) {
    const existing = [];
    for (const path of paths) if (await exists(path)) existing.push(path);
    if (existing.length > 0) throw new Error(`Refusing to overwrite existing PayProof files: ${existing.join(", ")}. Use --force to replace them.`);
  }
  await mkdir(testDirectory, { recursive: true });
  await writeFile(configPath, configTemplate, "utf8");
  await writeFile(testPath, testTemplate, "utf8");
  return paths;
}
