import { createJiti } from "jiti";
import { resolve } from "node:path";
import { PayProof, type PaymentEvent, type ProviderAdapter } from "@payproof/core";
import { signBachsWebhook } from "@payproof/bachs";
import type { PayProofCliRun, PayProofConfig, RunConfigOptions } from "./types.js";

function assertConfig(value: unknown): asserts value is PayProofConfig {
  if (!value || typeof value !== "object") throw new Error("PayProof config must export a default object");
  const config = value as Partial<PayProofConfig>;
  if (!config.provider || typeof config.provider !== "object") throw new Error("PayProof config requires a provider adapter");
  if (!config.target || typeof config.target !== "object" || typeof config.target.baseUrl !== "string" || typeof config.target.webhookPath !== "string") {
    throw new Error("PayProof config requires target.baseUrl and target.webhookPath");
  }
  if (!Array.isArray(config.tests) || config.tests.length === 0) throw new Error("PayProof config requires at least one test");
}

/** Load .mjs, .js, .cjs, or TypeScript config without requiring a repo-local loader. */
export async function loadConfig(configPath = "payproof.config.mjs"): Promise<PayProofConfig> {
  const absolutePath = resolve(process.cwd(), configPath);
  const jiti = createJiti(absolutePath, { interopDefault: true });
  const loaded = await jiti.import(absolutePath, { default: true }) as unknown;
  assertConfig(loaded);
  return loaded;
}

function withBachsSigning<TEvent extends PaymentEvent>(provider: ProviderAdapter<TEvent>, config: PayProofConfig<TEvent>): ProviderAdapter<TEvent> {
  if (!config.signing) return provider;
  if (config.signing.type !== "bachs") throw new Error(`Unsupported signing type ${String(config.signing.type)}`);
  if (!config.signing.secret) throw new Error("Bachs signing is configured but its secret is empty");
  return {
    ...provider,
    headers(event) {
      const rawBody = provider.serialize(event);
      return {
        ...(provider.headers?.(event) ?? {}),
        ...signBachsWebhook(rawBody, config.signing?.secret ?? "", config.signing?.timestamp)
      };
    }
  };
}

export async function runConfig(config: PayProofConfig, options: RunConfigOptions = {}): Promise<PayProofCliRun[]> {
  const tests = options.testName ? config.tests.filter((test) => test.name === options.testName) : config.tests;
  if (tests.length === 0) throw new Error(options.testName ? `No PayProof test named ${options.testName}` : "PayProof config contains no tests");
  if (config.requireFinancialVerification && !config.verify && !config.verification) {
    throw new Error("Financial verification is required, but the config has no verify callback or verification endpoint");
  }

  const provider = withBachsSigning(config.provider, config);
  const results: PayProofCliRun[] = [];
  for (const test of tests) {
    const { name, ...runOptions } = test;
    const runner = new PayProof({
      provider,
      target: config.target,
      verify: config.verify,
      verification: config.verification,
      checkpoint: config.checkpoint
    });
    const result = await runner.run(runOptions);
    if (config.requireFinancialVerification && !result.report.financiallyVerified) {
      result.report.errors.push("Financial verification was required but did not run");
      result.passed = false;
    }
    results.push({ name, result });
  }
  return results;
}
