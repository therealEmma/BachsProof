import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { initProject } from "./init.js";
import { loadConfig, runConfig } from "./runner.js";

function usage(): string {
  return `PayProof payment correctness testing

Usage:
  payproof init [directory] [--force]
  payproof test [--config <path>] [--name <test-name>] [--json]

init creates payproof.config.mjs and tests/payproof.test.mjs.
test sends configured provider events to the target webhook and reports delivery
and, when configured, committed financial verification results.
`;
}

function valueAfter(args: string[], flag: string): string | undefined {
  const index = args.indexOf(flag);
  return index >= 0 ? args[index + 1] : undefined;
}

function has(args: string[], flag: string): boolean {
  return args.includes(flag);
}

function redact(value: string, secret?: string): string {
  return secret ? value.replaceAll(secret, "[redacted]") : value;
}

export async function main(args = process.argv.slice(2)): Promise<number> {
  const command = args[0];
  if (!command || command === "--help" || command === "-h") {
    console.log(usage());
    return 0;
  }
  if (command === "init") {
    const directory = args.find((arg, index) => index > 0 && !arg.startsWith("-")) ?? process.cwd();
    const paths = await initProject(directory, has(args, "--force"));
    for (const path of paths) console.log(`created ${path}`);
    console.log("Next: set PAYPROOF_TARGET_URL, then run payproof test.");
    return 0;
  }
  if (command !== "test") throw new Error(`Unknown command ${command}\n\n${usage()}`);

  const configPath = valueAfter(args, "--config") ?? "payproof.config.mjs";
  const testName = valueAfter(args, "--name");
  const config = await loadConfig(configPath);
  const results = await runConfig(config, { testName });
  const failed = results.some(({ result }) => !result.passed);
  if (has(args, "--json")) {
    const json = JSON.stringify(results, null, 2);
    console.log(redact(json, config.signing?.secret));
  } else {
    console.log(`PayProof: ${resolve(configPath)}`);
    for (const { name, result } of results) {
      const verification = result.report.financiallyVerified ? "financially verified" : "delivery-only; financial verification not configured";
      console.log(`${result.passed ? "PASS" : "FAIL"} ${name} (${verification})`);
      for (const error of result.report.errors) console.log(`  ${redact(error, config.signing?.secret)}`);
    }
    if (!config.verify && !config.verification) {
      console.log("WARNING: black-box delivery success is not deterministic race coverage and does not prove committed financial correctness.");
    }
  }
  return failed ? 1 : 0;
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  main().then((code) => {
    process.exitCode = code;
  }).catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  });
}
