# Financial invariants

- `INV-001` Unique Credit: one eligible payment reference has at most one posted credit.
- `INV-002` Amount Integrity: the posted amount and currency equal the expected integer minor-unit values.
- `INV-003` Completion: an eligible payment receives its expected credit.
- `INV-004` No Unexpected Credit: an ineligible payment receives no credit.
- `INV-005` Aggregate Integrity: the observed amount for the payment equals the expected amount.

The verifier takes state returned either by the recommended `verify(reference)` callback or by the legacy application inspection endpoint. Callback values are validated with Zod before evaluation. HTTP success is not treated as financial success. Individual references are checked, and amounts remain integer minor units throughout.
