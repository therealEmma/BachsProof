# PayProof v1.1

PayProof is an SDK-first TypeScript framework for finding payment correctness bugs under controlled concurrency. The MVP demonstrates the important case: two deliveries of one Bachs-style payment are paused after the idempotency read, then released together and checked against persisted wallet state.

The repository contains:

- `@payproof/core`: orchestration, race controller, invariants, reports, and replay.
- `@payproof/sdk`: opt-in checkpoint instrumentation.
- `@payproof/bachs`: documented Bachs webhook envelope schemas, exact decimal parsing, and explicit synthetic fixtures. Mock events are not authentic sandbox deliveries.
- `apps/reference-wallet`: Express 5 + Prisma/PostgreSQL reference wallet with vulnerable and corrected handlers.
- `examples/vitest-integration`: a working Vitest usage example.
- `examples/standalone-callback`: an independent-project example that consumes generated package archives.

## Quick start without PostgreSQL

This path exercises the full controller, HTTP delivery, Express handlers, persisted test-store behavior, invariant checks, replay, and Vitest integration.

```bash
pnpm install
pnpm test
```

The test-only in-memory store is explicit in the tests. It does not replace the production Prisma path. The PostgreSQL suite is separate and is skipped unless `DATABASE_URL` is configured and reachable.

## Integration levels

PayProof supports three progressively stronger modes:

1. Basic event testing: provide a webhook URL and omit verification. `result.passed` means deliveries completed, but `result.report.financiallyVerified` is `false`; this mode cannot establish financial correctness.
2. Financial correctness testing: provide the recommended `verify(reference)` callback. PayProof validates the callback result with Zod and runs the financial invariants without requiring a state HTTP endpoint.
3. Controlled concurrency testing: add the checkpoint SDK and instrument the application at a named barrier so PayProof can reproduce a race instead of relying on timing luck.

## PostgreSQL reference wallet

The application uses PostgreSQL through Prisma and reads `DATABASE_URL`, including Railway's externally accessible URL. Copy `.env.example`, fill the URL in your local environment, and apply the checked-in migration:

```bash
Copy-Item .env.example .env
# Set DATABASE_URL to the dedicated Railway test database URL.
pnpm --filter @payproof/reference-wallet db:generate
pnpm --filter @payproof/reference-wallet db:migrate:deploy
$env:PAYPROOF_TEST_MODE="true"
$env:PAYPROOF_WALLET_MODE="vulnerable"
pnpm --filter @payproof/reference-wallet start
```

Run with `PAYPROOF_WALLET_MODE=corrected` to exercise the atomic handler. `PAYPROOF_ALLOW_DESTRUCTIVE_RESET=true` is required before the global reset endpoint can delete PostgreSQL rows; Railway tests use scoped reference cleanup instead. Never aim this app at a production database.

## Programmatic usage

```ts
import { PayProof } from "@payproof/core";
import { bachsAdapter } from "@payproof/bachs";

const payproof = new PayProof({
  provider: bachsAdapter({ mode: "mock" }),
  target: { baseUrl: "http://localhost:3000", webhookPath: "/webhooks/bachs" },
  verify: async (reference) => {
    const credits = await prisma.walletCredit.findMany({ where: { reference } });
    return {
      reference,
      creditCount: credits.length,
      creditedAmountMinor: credits.reduce((sum, credit) => sum + Number(credit.amountMinor), 0),
      currency: "NGN"
    };
  },
  checkpoint: { name: "after-idempotency-check" }
});

const result = await payproof.run({
  scenario: "concurrent-duplicate-credit",
  concurrency: 2
});
if (!result.passed) console.error(result.report);
```

Callback verification is preferred for TypeScript applications because it can use existing Prisma or database code directly. The existing HTTP adapter remains supported by replacing `verify` with `verification: { endpoint: "/__payproof/state" }`.

Instrument the application at the idempotency read:

```ts
await checkpoint("after-idempotency-check", { key: payment.reference });
```

Install the SDK middleware only in an explicitly authorized test environment. When disabled, `checkpoint` returns immediately and has no controller dependency.

## Demonstration

The integration test is the end-to-end demonstration:

```bash
pnpm vitest run apps/reference-wallet/tests/wallet.integration.test.ts
pnpm test:postgres
```

The first command runs without PostgreSQL. The second command runs actual PostgreSQL tests when `DATABASE_URL` is configured; otherwise Vitest reports them as skipped with an explicit explanation. The vulnerable handler produces two committed credit records and fails `INV-001`/`INV-002`; the corrected handler uses a transaction plus a unique idempotency key and produces one credit under the same schedule.

## Package validation

```bash
pnpm pack:check
```

This creates local npm archives in `reports/`; nothing is published.

To exercise the archive-based independent example after packing:

```bash
pnpm --dir examples/standalone-callback install
pnpm --dir examples/standalone-callback test
```

## Architecture

```mermaid
flowchart LR
  Test[Vitest test] --> Core[@payproof/core]
  Core --> Adapter[@payproof/bachs mock adapter]
  Core -->|concurrent HTTP deliveries| Wallet[Express 5 reference wallet]
  Wallet --> SDK[@payproof/sdk checkpoint]
  SDK --> Controller[Race Controller barrier]
  Wallet --> DB[(PostgreSQL / Prisma)]
  Core --> Verify[State inspection + invariants]
  Verify --> Report[JSON report + replay plan]
```

## Limitations and next steps

The reference wallet supports verified Bachs webhook envelopes and the official `@bachs/sdk` raw-body signature helper. The adapter's deterministic fixtures remain mock-only; they are not presented as sandbox deliveries. The repository does not call live Bachs APIs or claim a sandbox payment result. The detailed boundary and the actual run evidence are in [the engineering demonstration report](docs/engineering-demo.md). Checkpoint replay controls the named barrier schedule; it does not claim deterministic operating-system, network, or database scheduling. The checked-in test run uses Node 20 in this environment, while the package engine target is Node 22+.

See the focused documentation in `docs/` for the architecture, controller, invariants, Bachs boundary, replay behavior, and Railway setup.
