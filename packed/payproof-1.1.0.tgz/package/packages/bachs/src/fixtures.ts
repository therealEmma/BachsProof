import { randomUUID } from "node:crypto";
import { z } from "zod";
import type { ExpectedPaymentState, PaymentEvent } from "@payproof/core";
import { formatBachsMoney, parseBachsMoney, safeNumberMoney, toBachsMinorUnits } from "./money.js";

const customerSchema = z.object({
  id: z.string().min(1).nullable().optional(),
  customer_id: z.string().min(1).nullable().optional(),
  email: z.string().email().nullable().optional(),
  name: z.string().nullable().optional()
}).passthrough();

const checkoutDataSchema = z.object({
  checkout_id: z.string().min(1),
  status: z.string().min(1),
  mode: z.string().min(1),
  payment_status: z.string().nullable(),
  amount: z.string().min(1),
  currency: z.string().length(3).nullable(),
  reference: z.string().min(1).nullable(),
  customer: customerSchema.nullable(),
  charge: z.object({ id: z.string().min(1) }).passthrough().nullable(),
  metadata: z.record(z.unknown()).default({})
}).passthrough();

const collectionDataSchema = z.object({
  charge_id: z.string().min(1).nullable(),
  checkout_id: z.string().min(1).nullable(),
  reference: z.string().min(1).nullable(),
  status: z.string().min(1),
  amount: z.string().min(1),
  currency: z.string().length(3),
  customer: customerSchema,
  metadata: z.record(z.unknown()).default({})
}).passthrough();

const genericDataSchema = z.record(z.unknown());

const eventEnvelope = z.object({
  id: z.string().min(1),
  type: z.string().min(1),
  created_at: z.string().datetime({ offset: true }),
  organization_id: z.string().min(1),
  data: genericDataSchema
}).passthrough();

export const BachsWebhookEventSchema = z.union([
  eventEnvelope.extend({ type: z.literal("checkout.completed"), data: checkoutDataSchema }),
  eventEnvelope.extend({ type: z.literal("checkout.expired"), data: checkoutDataSchema }),
  eventEnvelope.extend({ type: z.literal("collection.succeeded"), data: collectionDataSchema }),
  // Bachs lists collection.underpaid as a supported event, but its dedicated
  // payload page is not part of the verified contract we inspected. Preserve
  // the full payload and deliberately treat it as non-fulfilling.
  eventEnvelope.extend({ type: z.literal("collection.underpaid"), data: genericDataSchema }),
  eventEnvelope.extend({ type: z.literal("collection.failed"), data: genericDataSchema }),
  eventEnvelope
]);

export type BachsWebhookEvent = z.infer<typeof BachsWebhookEventSchema>;
type CheckoutData = z.infer<typeof checkoutDataSchema>;
type CollectionData = z.infer<typeof collectionDataSchema>;

export interface NormalizedBachsPayment {
  eventId: string;
  eventType: BachsWebhookEvent["type"];
  eventCreatedAt: string;
  reference?: string;
  amountMinor?: number;
  amountScale?: number;
  amount?: string;
  currency?: string;
  customerId?: string;
  providerPaymentId?: string;
  checkoutId?: string;
  eligible: boolean;
  status: string;
}

export interface BachsPaymentEvent extends PaymentEvent {
  id: string;
  type: "collection.succeeded";
  created_at: string;
  organization_id: string;
  data: z.infer<typeof collectionDataSchema>;
  /** Normalized fields used by the provider-neutral core. */
  reference: string;
  amountMinor: number;
  amountScale: number;
  currency: string;
  status: string;
  customerId: string;
  providerPaymentId: string;
  checkoutId: string;
  eligible: boolean;
}

export interface BachsFixtureOptions {
  reference?: string;
  amountMinor?: number;
  currency?: string;
  eligible?: boolean;
  customerId?: string;
}

/** Generate a deterministic local fixture with the documented collection envelope. */
export function createBachsMockFixture(options: BachsFixtureOptions = {}): BachsPaymentEvent {
  const eligible = options.eligible !== false;
  const reference = options.reference ?? `PAY-${randomUUID().slice(0, 8).toUpperCase()}`;
  const currency = options.currency ?? "NGN";
  const amountMinor = options.amountMinor ?? 5_000_000;
  const amount = formatBachsMoney(BigInt(amountMinor), 2);
  const exactAmount = parseBachsMoney(amount, currency);
  const providerPaymentId = `ch_${randomUUID().replaceAll("-", "")}`;
  const checkoutId = `chk_${randomUUID().replaceAll("-", "")}`;
  return {
    id: `evt_${randomUUID().replaceAll("-", "")}`,
    type: "collection.succeeded",
    created_at: new Date().toISOString(),
    organization_id: "acct_payproof_test",
    data: {
      charge_id: providerPaymentId,
      checkout_id: checkoutId,
      reference,
      status: eligible ? "SUCCEEDED" : "ACCEPTED",
      amount,
      currency,
      settlement_amount: amount,
      settlement_currency: currency,
      fee_bearer: "merchant",
      product_cart: null,
      customer: { id: options.customerId ?? "customer-test-001", email: "synthetic@example.com", name: "Synthetic Customer" },
      payment_method_details: null,
      metadata: { order_id: reference }
    },
    reference,
    amountMinor: safeNumberMoney(toBachsMinorUnits(exactAmount, 2)),
    amountScale: 2,
    currency,
    status: eligible ? "SUCCEEDED" : "ACCEPTED",
    customerId: options.customerId ?? "customer-test-001",
    providerPaymentId,
    checkoutId,
    eligible
  };
}

/** Serialize only the authentic provider envelope, excluding normalized fields. */
export function serializeBachsPaymentEvent(event: BachsPaymentEvent): string {
  return JSON.stringify({
    id: event.id,
    type: event.type,
    created_at: event.created_at,
    organization_id: event.organization_id,
    data: event.data
  });
}

/** Validate an externally supplied documented Bachs webhook envelope. */
export function parseBachsWebhookEvent(value: unknown): BachsWebhookEvent {
  return BachsWebhookEventSchema.parse(value);
}

function stringField(value: unknown): string | undefined {
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function customerId(value: unknown): string | undefined {
  if (!value || typeof value !== "object") return undefined;
  const candidate = value as Record<string, unknown>;
  return stringField(candidate.id) ?? stringField(candidate.customer_id);
}

/** Normalize only fields verified in the documented event examples. */
export function normalizeBachsWebhookEvent(value: unknown): NormalizedBachsPayment {
  const event = parseBachsWebhookEvent(value);
  if (event.type === "checkout.completed" || event.type === "checkout.expired") {
    const data = event.data as CheckoutData;
    const amount = data.currency ? parseBachsMoney(data.amount, data.currency) : undefined;
    const eligible = event.type === "checkout.completed"
      && data.status === "completed"
      && data.mode === "payment"
      && data.payment_status === "paid"
      && data.charge !== null
      && data.currency !== null;
    return {
      eventId: event.id,
      eventType: event.type,
      eventCreatedAt: event.created_at,
      reference: data.reference ?? undefined,
      amountMinor: amount ? safeNumberMoney(toBachsMinorUnits(amount, amount.scale)) : undefined,
      amountScale: amount?.scale,
      amount: data.amount,
      currency: data.currency ?? undefined,
      customerId: customerId(data.customer),
      providerPaymentId: data.charge?.id,
      checkoutId: data.checkout_id,
      eligible,
      status: eligible ? "SUCCEEDED" : data.status
    };
  }

  if (event.type === "collection.succeeded") {
    const data = event.data as CollectionData;
    const amount = parseBachsMoney(data.amount, data.currency);
    const eligible = data.status === "SUCCEEDED";
    return {
      eventId: event.id,
      eventType: event.type,
      eventCreatedAt: event.created_at,
      reference: data.reference ?? undefined,
      amountMinor: safeNumberMoney(toBachsMinorUnits(amount, amount.scale)),
      amountScale: amount.scale,
      amount: data.amount,
      currency: data.currency,
      customerId: customerId(data.customer),
      providerPaymentId: data.charge_id ?? undefined,
      checkoutId: data.checkout_id ?? undefined,
      eligible,
      status: data.status
    };
  }

  // The dedicated underpaid/failed payload pages were not available in the
  // inspected contract. Use optional fields only when present and never mark
  // these events eligible for a wallet credit.
  const data = event.data as Record<string, unknown>;
  const reference = stringField(data.reference);
  const amount = stringField(data.amount);
  const currency = stringField(data.currency);
  let amountMinor: number | undefined;
  let amountScale: number | undefined;
  if (amount && currency) {
    const exact = parseBachsMoney(amount, currency);
    amountMinor = safeNumberMoney(toBachsMinorUnits(exact, exact.scale));
    amountScale = exact.scale;
  }
  return {
    eventId: event.id,
    eventType: event.type,
    eventCreatedAt: event.created_at,
    reference,
    amountMinor,
    amountScale,
    amount,
    currency,
    customerId: customerId(data.customer),
    providerPaymentId: stringField(data.charge_id),
    checkoutId: stringField(data.checkout_id),
    eligible: false,
    status: event.type === "collection.underpaid" ? "UNDERPAID" : "FAILED"
  };
}

/** Translate provider metadata into the core's expected-state model. */
export function expectedBachsState(event: BachsPaymentEvent): ExpectedPaymentState {
  return {
    reference: event.reference,
    eligible: event.eligible,
    amountMinor: event.amountMinor,
    currency: event.currency,
    expectedCreditCount: 1
  };
}
