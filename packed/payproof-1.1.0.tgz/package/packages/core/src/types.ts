/** The scenarios currently implemented by the provider-neutral runner. */
export type ScenarioName =
  | "concurrent-duplicate-credit"
  | "sequential-duplicate-webhook"
  | "concurrent-unique-payments";

/** Minimal shape every provider adapter event must expose to the core engine. */
export interface PaymentEvent {
  reference: string;
  amountMinor: number;
  currency: string;
  status: string;
  [key: string]: unknown;
}

/** The state the application should have after processing one synthetic event. */
export interface ExpectedPaymentState {
  reference: string;
  eligible: boolean;
  amountMinor: number;
  currency: string;
  expectedCreditCount: number;
}

/**
 * Provider plug-in contract. The core never knows how a Bachs event (or a
 * future provider event) is shaped on the wire; it only uses this contract.
 */
export interface ProviderAdapter<TEvent extends PaymentEvent = PaymentEvent> {
  readonly name: string;
  readonly mode: string;
  createPayment(input?: {
    reference?: string;
    amountMinor?: number;
    currency?: string;
    eligible?: boolean;
    customerId?: string;
  }): TEvent;
  serialize(event: TEvent): string;
  expectedState(event: TEvent): ExpectedPaymentState;
  headers?(event: TEvent): Record<string, string>;
}

/**
 * Normalized persisted financial state returned by either an HTTP endpoint or
 * a developer-supplied verification callback.
 */
export interface ObservedPaymentState {
  reference: string;
  status: string;
  currency: string;
  creditedAmountMinor: number;
  creditCount: number;
  ledgerEntries: Array<{
    id: string;
    type: string;
    amountMinor: number;
    currency?: string;
  }>;
}

export type InvariantId = "INV-001" | "INV-002" | "INV-003" | "INV-004" | "INV-005";

export interface InvariantViolation {
  id: InvariantId;
  name: string;
  message: string;
  reference: string;
}

/** Result of evaluating all configured financial invariants for one reference. */
export interface VerificationResult {
  passed: boolean;
  violations: InvariantViolation[];
}

/** One attempted webhook delivery, including its HTTP outcome and timing. */
export interface DeliveryRecord {
  deliveryId: string;
  participantId: string;
  reference: string;
  startedAt: string;
  completedAt?: string | undefined;
  status?: number | undefined;
  responseBody?: string | undefined;
  error?: string | undefined;
}

/** An append-only event emitted by the race controller for replay/debugging. */
export interface CheckpointTraceEvent {
  type: "arrival" | "release" | "abort";
  at: string;
  sessionId: string;
  checkpoint: string;
  participantId?: string | undefined;
  key?: string | undefined;
  metadata?: Record<string, unknown> | undefined;
  reason?: string | undefined;
}

/** Structured report persisted by callers when they need a durable failure trace. */
export interface PayProofReport {
  reportVersion: "1.1";
  scenario: ScenarioName;
  provider: string;
  mode: string;
  paymentReference: string;
  event: PaymentEvent;
  expected: ExpectedPaymentState;
  observed?: ObservedPaymentState;
  verification?: VerificationResult;
  /** Which state-inspection integration was used for this run. */
  verificationMode: "callback" | "http" | "none";
  /** False means HTTP delivery ran, but financial correctness was not established. */
  financiallyVerified: boolean;
  payments?: Array<{
    event: PaymentEvent;
    expected: ExpectedPaymentState;
    observed: ObservedPaymentState;
    verification: VerificationResult;
  }>;
  deliveries: DeliveryRecord[];
  checkpoints: CheckpointTraceEvent[];
  errors: string[];
  replay: {
    seed: string;
    concurrency: number;
    checkpoint?: string;
    controlled: true;
    note: string;
  };
  startedAt: string;
  completedAt?: string;
}

export interface PayProofResult {
  passed: boolean;
  report: PayProofReport;
}

/** Network details for the application under test. */
export interface PayProofTarget {
  baseUrl: string;
  webhookPath: string;
  resetPath?: string;
  /** Set false when the target has no PayProof reset route or owns isolation itself. */
  reset?: boolean;
  headers?: Record<string, string>;
}

/** Legacy/alternative HTTP state inspection configuration. */
export interface PayProofVerificationOptions {
  endpoint: string;
  headers?: Record<string, string>;
  completionDeadlineMs?: number;
  pollIntervalMs?: number;
}

/**
 * The intentionally small callback contract recommended for TypeScript users.
 * Callers can use Prisma, SQL, an in-memory ledger, or any other test store.
 */
export interface FinancialVerificationInput {
  reference: string;
  creditCount: number;
  creditedAmountMinor: number;
  currency: string;
  status?: string;
  ledgerEntries?: Array<{
    id: string;
    type: string;
    amountMinor: number;
    currency?: string;
  }>;
}

export type FinancialVerifier = (reference: string) => Promise<FinancialVerificationInput> | FinancialVerificationInput;

export interface PayProofOptions<TEvent extends PaymentEvent = PaymentEvent> {
  provider: ProviderAdapter<TEvent>;
  target: PayProofTarget;
  /** Recommended verification path; no HTTP inspection route is needed. */
  verify?: FinancialVerifier;
  /** Backward-compatible HTTP inspection path. */
  verification?: PayProofVerificationOptions;
  checkpoint?: {
    name: string;
    timeoutMs?: number;
  };
}

/** Per-run scenario settings, including replay overrides. */
export interface RunOptions {
  scenario: ScenarioName;
  concurrency?: number;
  amountMinor?: number;
  currency?: string;
  reference?: string;
  seed?: string;
  replay?: PayProofReport;
}
