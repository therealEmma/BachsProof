import { randomUUID } from "node:crypto";
import { fetch } from "undici";
import { RaceController } from "./race-controller.js";
import { verifyPaymentState } from "./invariants.js";
import { verifyWithCallback } from "./verification.js";
import type {
  DeliveryRecord,
  ObservedPaymentState,
  PayProofOptions,
  PayProofReport,
  PayProofResult,
  PaymentEvent,
  RunOptions
} from "./types.js";

const DEFAULT_TIMEOUT_MS = 10_000;

/**
 * High-level PayProof runner. It owns only test orchestration; the application
 * remains responsible for webhook authentication and business persistence.
 */
export class PayProof<TEvent extends PaymentEvent = PaymentEvent> {
  /** Store the immutable configuration used by every run and replay. */
  constructor(private readonly options: PayProofOptions<TEvent>) {}

  async run(input: RunOptions): Promise<PayProofResult> {
    // A run creates one logical event and then chooses a delivery schedule.
    // Replay replaces event generation with the serialized event from a report.
    const startedAt = new Date().toISOString();
    const concurrency = Math.max(1, input.concurrency ?? (input.scenario === "concurrent-duplicate-credit" ? 2 : 1));
    const seed = input.seed ?? input.replay?.replay.seed ?? randomUUID();
    const event = (input.replay?.event as TEvent | undefined) ?? this.options.provider.createPayment({
      reference: input.reference,
      amountMinor: input.amountMinor,
      currency: input.currency
    });
    const expected = this.options.provider.expectedState(event);
    let eventsForVerification: TEvent[] = [event];
    // The report is initialized before network work so even reset/controller
    // failures produce a useful artifact.
    const report: PayProofReport = {
      reportVersion: "1.1",
      scenario: input.scenario,
      provider: this.options.provider.name,
      mode: this.options.provider.mode,
      paymentReference: event.reference,
      event,
      expected,
      verificationMode: this.options.verify ? "callback" : this.options.verification ? "http" : "none",
      financiallyVerified: false,
      deliveries: [],
      checkpoints: [],
      errors: [],
      replay: {
        seed,
        concurrency,
        checkpoint: this.options.checkpoint?.name,
        controlled: true,
        note: "Replay controls explicitly instrumented checkpoints; it does not claim deterministic OS, network, or database scheduling."
      },
      startedAt
    };

    let controller: RaceController | undefined;
    let sessionId: string | undefined;
    try {
      await this.resetTarget();
      const checkpoint = input.scenario === "concurrent-duplicate-credit" ? this.options.checkpoint?.name : undefined;
      if (checkpoint) {
        // Controlled-concurrency mode registers every participant before any
        // webhook is sent, removing dependence on random request timing.
        controller = new RaceController();
        const participants = Array.from({ length: concurrency }, (_, index) => `participant-${index + 1}`);
        const session = await controller.registerSession({ participants });
        sessionId = session.id;
        const deliveries = participants.map((participantId) => this.deliver(event, participantId, session, report));
        try {
          await controller.waitForArrivals(session.id, checkpoint, concurrency, this.options.checkpoint?.timeoutMs ?? DEFAULT_TIMEOUT_MS);
          controller.release(session.id, checkpoint);
        } catch (error) {
          report.errors.push(error instanceof Error ? error.message : String(error));
          controller.abort(session.id, "arrival-timeout");
        }
        await Promise.all(deliveries);
        report.checkpoints = controller.getTrace(session.id);
      } else if (input.scenario === "sequential-duplicate-webhook") {
        // Sequential mode intentionally leaves the checkpoint disabled; it
        // verifies ordinary idempotency without a race barrier.
        await this.deliver(event, "sequential-1", undefined, report);
        await this.deliver(event, "sequential-2", undefined, report);
      } else if (input.scenario === "concurrent-unique-payments") {
        // Unique events share a delivery wave but use distinct references, so
        // the verifier can validate each payment individually.
        const events = Array.from({ length: concurrency }, (_, index) => this.options.provider.createPayment({
          amountMinor: input.amountMinor,
          currency: input.currency,
          reference: `${event.reference}-${index + 1}`
        }));
        await Promise.all(events.map((uniqueEvent) => this.deliver(uniqueEvent, `unique-${uniqueEvent.reference}`, undefined, report)));
        eventsForVerification = events;
      } else {
        report.errors.push(`Unsupported scenario ${input.scenario}`);
      }

      // Level 1 intentionally stops after delivery. It is useful for webhook
      // contract testing, but it cannot prove that money was persisted safely.
      if (!this.options.verify && !this.options.verification) {
        report.financiallyVerified = false;
      } else {
        // Inspect each reference separately. Aggregate balance checks alone
        // could miss one over-credit and one under-credit cancelling out.
        const paymentResults = await Promise.all(eventsForVerification.map(async (paymentEvent) => {
          const paymentExpected = this.options.provider.expectedState(paymentEvent);
          const paymentObserved = await this.inspect(paymentEvent.reference);
          return {
            event: paymentEvent,
            expected: paymentExpected,
            observed: paymentObserved,
            verification: verifyPaymentState(paymentExpected, paymentObserved)
          };
        }));
        report.financiallyVerified = true;
        report.observed = paymentResults[0]?.observed;
        report.verification = {
          passed: paymentResults.every((payment) => payment.verification.passed),
          violations: paymentResults.flatMap((payment) => payment.verification.violations)
        };
        if (paymentResults.length > 1) report.payments = paymentResults;
        if (!report.verification.passed) {
          report.errors.push(...report.verification.violations.map((violation) => `${violation.id}: ${violation.message}`));
        }
      }
    } catch (error) {
      report.errors.push(error instanceof Error ? error.message : String(error));
    } finally {
      if (controller && sessionId) {
        report.checkpoints = controller.getTrace(sessionId);
        controller.cleanupSession(sessionId);
      }
      if (controller) await controller.close();
      report.completedAt = new Date().toISOString();
    }
    const financialPass = !report.financiallyVerified || report.verification?.passed === true;
    return { passed: report.errors.length === 0 && financialPass, report };
  }

  async replay(report: PayProofReport): Promise<PayProofResult> {
    // Reset/isolation and controller setup are intentionally delegated to run;
    // replay only supplies the prior event and schedule metadata.
    return this.run({
      scenario: report.scenario,
      concurrency: report.replay.concurrency,
      seed: report.replay.seed,
      replay: report
    });
  }

  private async resetTarget(): Promise<void> {
    // A target can opt out when it manages isolation itself, which is useful
    // for an existing application or a remotely hosted Railway test database.
    if (this.options.target.reset === false) return;
    const path = this.options.target.resetPath ?? "/__payproof/reset";
    const response = await fetch(this.url(path), {
      method: "POST",
      headers: this.options.target.headers
    });
    if (!response.ok) throw new Error(`Test-state reset failed with HTTP ${response.status}`);
  }

  private async deliver(
    event: TEvent,
    participantId: string,
    session: { id: string; token: string; controllerUrl: string } | undefined,
    report: PayProofReport
  ): Promise<void> {
    // Delivery records are created before fetch so connection errors still have
    // a participant, start time, and eventual error entry in the report.
    const delivery: DeliveryRecord = {
      deliveryId: randomUUID(),
      participantId,
      reference: event.reference,
      startedAt: new Date().toISOString()
    };
    const headers: Record<string, string> = {
      "content-type": "application/json",
      ...this.options.target.headers,
      ...(this.options.provider.headers?.(event) ?? {})
    };
    if (session) {
      headers["x-payproof-enabled"] = "true";
      headers["x-payproof-controller"] = session.controllerUrl;
      headers["x-payproof-session"] = session.id;
      headers["x-payproof-participant"] = participantId;
      headers["x-payproof-token"] = session.token;
    }
    try {
      const response = await fetch(this.url(this.options.target.webhookPath), {
        method: "POST",
        headers,
        body: this.options.provider.serialize(event)
      });
      delivery.status = response.status;
      delivery.responseBody = await response.text();
      if (!response.ok) throw new Error(`Webhook delivery ${participantId} failed with HTTP ${response.status}: ${delivery.responseBody}`);
    } catch (error) {
      delivery.error = error instanceof Error ? error.message : String(error);
      throw error;
    } finally {
      delivery.completedAt = new Date().toISOString();
      // Delivery records are appended after each request so reports retain failures.
      report.deliveries.push(delivery);
    }
  }

  private async inspect(reference: string): Promise<ObservedPaymentState> {
    if (this.options.verify) {
      return verifyWithCallback(this.options.verify, reference, this.options.verification?.completionDeadlineMs ?? DEFAULT_TIMEOUT_MS);
    }
    const verification = this.options.verification;
    if (!verification) {
      throw new Error("Financial verification was requested without a callback or HTTP endpoint");
    }
    // HTTP verification remains supported for existing users. Callback mode
    // returns above, so this branch is only reached when an endpoint exists.
    const endpoint = verification.endpoint;
    const url = new URL(this.url(endpoint));
    url.searchParams.set("reference", reference);
    const deadline = Date.now() + (verification.completionDeadlineMs ?? DEFAULT_TIMEOUT_MS);
    let lastError: Error | undefined;
    // Polling accommodates applications that enqueue work after returning the
    // webhook response. The deadline keeps a broken app from hanging a suite.
    while (Date.now() <= deadline) {
      try {
        const response = await fetch(url, { headers: { ...this.options.target.headers, ...verification.headers } });
        if (!response.ok) throw new Error(`State inspection failed with HTTP ${response.status}`);
        const value = await response.json() as ObservedPaymentState;
        if (value.reference === reference) return value;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
      }
      await new Promise((resolve) => setTimeout(resolve, verification.pollIntervalMs ?? 25));
    }
    throw lastError ?? new Error(`No state returned for payment ${reference}`);
  }

  private url(path: string): string {
    return new URL(path, this.options.target.baseUrl).toString();
  }
}
