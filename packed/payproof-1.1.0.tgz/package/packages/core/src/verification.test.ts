import { describe, expect, it } from "vitest";
import { verifyWithCallback } from "./verification.js";

describe("callback verification", () => {
  it("validates and normalizes callback state", async () => {
    const state = await verifyWithCallback(async (reference) => ({
      reference,
      creditCount: 1,
      creditedAmountMinor: 5_000_000,
      currency: "NGN"
    }), "PAY-001", 100);
    expect(state.status).toBe("UNKNOWN");
    expect(state.creditCount).toBe(1);
  });

  it("rejects a callback result for the wrong reference", async () => {
    await expect(verifyWithCallback(() => ({
      reference: "PAY-WRONG",
      creditCount: 0,
      creditedAmountMinor: 0,
      currency: "NGN"
    }), "PAY-001", 100)).rejects.toThrow("PAY-WRONG");
  });

  it("bounds a callback that never resolves", async () => {
    await expect(verifyWithCallback(() => new Promise(() => undefined), "PAY-001", 10)).rejects.toThrow("timed out");
  });
});
