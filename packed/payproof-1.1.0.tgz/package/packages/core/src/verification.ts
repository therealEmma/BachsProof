import { z } from "zod";
import type { FinancialVerificationInput, ObservedPaymentState } from "./types.js";

/**
 * Runtime validation is important here because a malformed callback result
 * could otherwise make an incorrect financial state look like a passed test.
 */
export const financialVerificationSchema = z.object({
  reference: z.string().min(1),
  creditCount: z.number().int().nonnegative(),
  creditedAmountMinor: z.number().int().nonnegative(),
  currency: z.string().length(3),
  status: z.string().min(1).optional(),
  ledgerEntries: z.array(z.object({
    id: z.string().min(1),
    type: z.string().min(1),
    amountMinor: z.number().int().nonnegative(),
    currency: z.string().length(3).optional()
  })).optional()
});

/**
 * Convert the public callback shape into the core's normalized observation
 * shape. The default status keeps the callback API small while preserving the
 * status field used by the HTTP adapter and reports.
 */
export function normalizeCallbackState(value: FinancialVerificationInput): ObservedPaymentState {
  const parsed = financialVerificationSchema.parse(value);
  return {
    reference: parsed.reference,
    status: parsed.status ?? "UNKNOWN",
    currency: parsed.currency,
    creditedAmountMinor: parsed.creditedAmountMinor,
    creditCount: parsed.creditCount,
    ledgerEntries: parsed.ledgerEntries ?? []
  };
}

/**
 * Execute a callback with a hard upper bound. JavaScript cannot forcibly stop
 * arbitrary user code, but the runner will stop waiting and report a timeout.
 */
export async function verifyWithCallback(
  verify: (reference: string) => Promise<FinancialVerificationInput> | FinancialVerificationInput,
  reference: string,
  timeoutMs: number
): Promise<ObservedPaymentState> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    const timeout = new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(`Financial verification timed out after ${timeoutMs}ms`)), timeoutMs);
    });
    const value = await Promise.race([Promise.resolve().then(() => verify(reference)), timeout]);
    const normalized = normalizeCallbackState(value);
    if (normalized.reference !== reference) {
      throw new Error(`Financial verification returned ${normalized.reference} while ${reference} was requested`);
    }
    return normalized;
  } finally {
    if (timer) clearTimeout(timer);
  }
}
