# @payproof/core

Provider-neutral orchestration, checkpoint coordination, financial invariants, reports, and replay for PayProof.

The recommended configuration supplies `verify(reference)`, which returns committed credit information directly from the application's own test database code. The older `verification.endpoint` HTTP adapter remains available for applications that prefer an isolated inspection route. Omitting both is valid for basic webhook/event testing, but `report.financiallyVerified` will be `false`.
